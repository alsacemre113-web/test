(function () {
  var $ = function (s) { return document.querySelector(s); };
  var CFG = null, dirty = false, previewTimer = null, frameReady = false;

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function sumTokens() {
    return CFG.tokens.reduce(function (s, t) { return s + (+t.p || 0); }, 0);
  }
  function sumOk() { return Math.abs(sumTokens() - 100) < 0.001; }

  function api(path, opts) {
    opts = opts || {};
    opts.credentials = "same-origin";
    opts.cache = "no-store";
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error(j.error || "Hata (" + r.status + ")"); e.status = r.status; throw e; }
        return j;
      });
    });
  }

  /* ---------- ekran geçişleri ---------- */
  function showLogin(msg) {
    $("#admin").hidden = true;
    $("#login").hidden = false;
    if (msg) $("#loginMsg").textContent = msg;
    setTimeout(function () { $("#pw").focus(); }, 0);
  }

  /* ---------- form ---------- */
  function F(label, path, o) {
    o = o || {};
    var v = path.split(".").reduce(function (a, k) { return a[k]; }, CFG);
    if (o.lines) v = v.join("\n");
    var a = ' data-p="' + path + '"' + (o.lines ? ' data-lines="1"' : "") + (o.num ? ' data-num="1"' : "");
    var field = (o.area || o.lines)
      ? "<textarea" + a + ">" + esc(v) + "</textarea>"
      : '<input' + a + ' type="' + (o.type || "text") + '" value="' + esc(v) + '">';
    return "<label>" + label + "</label>" + field + (o.hint ? '<div class="hint">' + o.hint + "</div>" : "");
  }

  function renderForm() {
    var c = CFG, h = "";
    h += "<h4>Genel</h4>" +
      F("Proje adı", "brand") + F("Ticker", "ticker") + F("Ağ (chain)", "chain") +
      F("Toplam arz (sayı)", "supply", { num: 1 }) + F("Kontrat adresi", "contract") +
      F("Slogan", "tagline", { area: 1 }) + F("Hakkında başlığı", "aboutTitle") +
      F("Hakkında metni", "aboutText", { area: 1 }) +
      F("Logo adresi", "logo", { hint: "Örn. /images/logo.jpg veya https://... ile başlayan bir adres." }) +
      F("Rozet adresi", "badge", { hint: "Hakkında bölümündeki yuvarlak görsel." });

    h += "<h4>Linkler</h4>" + c.links.map(function (l, i) {
      return '<div class="card">' + F("Buton adı", "links." + i + ".name") +
        F("URL", "links." + i + ".url", { hint: "https:// ile başlamalı (veya # boş bırakır)." }) +
        '<button class="sm red" data-a="dl:' + i + '" type="button">Sil</button></div>';
    }).join("") + '<button class="sm" data-a="al" type="button">+ Link ekle</button>';

    h += '<h4 id="tokH">Tokenomics (toplam: ' + (+sumTokens().toFixed(2)) + "%)</h4>" +
      '<div class="st bad" id="tokWarn"' + (sumOk() ? " hidden" : "") + ">Toplam %100 olmalı.</div>" +
      c.tokens.map(function (t, i) {
        return '<div class="card">' + F("Ad", "tokens." + i + ".n") +
          '<div class="row"><div>' + F("Açıklama", "tokens." + i + ".d") + "</div><div>" +
          F("%", "tokens." + i + ".p", { num: 1 }) + "</div><div>" +
          F("Renk", "tokens." + i + ".c", { type: "color" }) + "</div></div>" +
          '<button class="sm red" data-a="dt:' + i + '" type="button">Sil</button></div>';
      }).join("") + '<button class="sm" data-a="at" type="button">+ Dilim ekle</button>';

    h += "<h4>Roadmap</h4>" + F("Alt başlık", "roadSub") + c.phases.map(function (p, i) {
      return '<div class="card">' + F("Faz başlığı", "phases." + i + ".title") +
        F("Etiket", "phases." + i + ".tag") +
        F("Maddeler (her satıra bir madde)", "phases." + i + ".items", { lines: 1 }) +
        '<button class="sm red" data-a="dp:' + i + '" type="button">Sil</button></div>';
    }).join("") + '<button class="sm" data-a="ap" type="button">+ Faz ekle</button>';

    h += "<h4>Nasıl alınır</h4>" + c.steps.map(function (s, i) {
      return '<div class="card">' + F("Başlık", "steps." + i + ".title") + F("Metin", "steps." + i + ".text") +
        '<button class="sm red" data-a="ds:' + i + '" type="button">Sil</button></div>';
    }).join("") + '<button class="sm" data-a="as" type="button">+ Adım ekle</button>';

    h += "<h4>Alt bilgi</h4>" + F("Uyarı 1", "disc1", { area: 1 }) + F("Uyarı 2", "disc2", { area: 1 });
    $("#form").innerHTML = h;
    updateSave();
  }

  function updateSave() {
    $("#save").disabled = !sumOk();
    var w = $("#tokWarn"), hd = $("#tokH");
    if (w) w.hidden = sumOk();
    if (hd) hd.textContent = "Tokenomics (toplam: " + (+sumTokens().toFixed(2)) + "%)";
  }

  function setP(path, v) {
    var k = path.split("."), o = CFG;
    for (var i = 0; i < k.length - 1; i++) o = o[k[i]];
    o[k[k.length - 1]] = v;
  }

  /* ---------- önizleme ---------- */
  function sendPreview() {
    var f = $("#frame");
    if (!frameReady || !f.contentWindow) return;
    f.contentWindow.postMessage({ type: "cfg", cfg: CFG }, location.origin);
  }
  function schedulePreview() {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(sendPreview, 120);
  }
  window.addEventListener("message", function (e) {
    if (e.origin !== location.origin) return;
    if (e.data && e.data.type === "ready") { frameReady = true; sendPreview(); }
  });

  function status(msg, cls) {
    var st = $("#st");
    st.className = "st" + (cls ? " " + cls : "");
    st.textContent = msg;
  }

  /* ---------- editör ---------- */
  function wire() {
    var form = $("#form");
    form.addEventListener("input", function (e) {
      var t = e.target, p = t.dataset.p;
      if (!p) return;
      var v = t.value;
      if (t.dataset.num) v = parseFloat(v) || 0;
      if (t.dataset.lines) v = v.split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
      setP(p, v);
      dirty = true;
      status("Kaydedilmemiş değişiklikler var.");
      updateSave();
      schedulePreview();
    });

    form.addEventListener("click", function (e) {
      var a = e.target.dataset && e.target.dataset.a;
      if (!a) return;
      var m = a.split(":"), i = +m[1], c = CFG;
      if (a === "al") c.links.push({ name: "Yeni link", url: "#" });
      else if (m[0] === "dl") c.links.splice(i, 1);
      else if (a === "at") c.tokens.push({ n: "Yeni dilim", p: 0, c: "#ffffff", d: "Açıklama" });
      else if (m[0] === "dt") c.tokens.splice(i, 1);
      else if (a === "ap") c.phases.push({ title: "Yeni faz", tag: "Etiket", items: ["Yeni hedef"] });
      else if (m[0] === "dp") c.phases.splice(i, 1);
      else if (a === "as") c.steps.push({ title: "Yeni adım", text: "Adımı açıkla." });
      else if (m[0] === "ds") c.steps.splice(i, 1);
      else return;
      dirty = true;
      status("Kaydedilmemiş değişiklikler var.");
      renderForm();
      schedulePreview();
    });

    $("#save").addEventListener("click", function () {
      var b = $("#save");
      b.disabled = true;
      status("Kaydediliyor...");
      api("/api/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(CFG),
      }).then(function () {
        dirty = false;
        status("Kaydedildi. Değişiklik birkaç saniye içinde canlı sitede görünür.", "ok");
      }).catch(function (err) {
        if (err.status === 401) { showLogin("Oturum süresi doldu, tekrar giriş yap."); return; }
        status(err.message, "bad");
      }).then(function () { updateSave(); });
    });

    $("#reset").addEventListener("click", function () {
      if (!confirm("Tüm ayarlar ilk (varsayılan) haline dönecek. Emin misin?")) return;
      api("/api/config", { method: "DELETE" }).then(function () {
        return api("/api/config?fresh=1&t=" + Date.now());
      }).then(function (cfg) {
        CFG = cfg; dirty = false; renderForm(); sendPreview();
        status("Varsayılan ayarlara dönüldü.", "ok");
      }).catch(function (err) {
        if (err.status === 401) { showLogin("Oturum süresi doldu, tekrar giriş yap."); return; }
        status(err.message, "bad");
      });
    });

    $("#logout").addEventListener("click", function () {
      if (dirty && !confirm("Kaydedilmemiş değişiklikler kaybolacak. Çıkılsın mı?")) return;
      dirty = false;
      api("/api/auth?action=logout", { method: "POST" }).catch(function () {}).then(function () {
        CFG = null; showLogin("Çıkış yapıldı.");
      });
    });
  }

  var wired = false;
  function startEditor(db) {
    api("/api/config?fresh=1&t=" + Date.now()).then(function (cfg) {
      CFG = cfg;
      $("#login").hidden = true;
      $("#admin").hidden = false;
      renderForm();
      if (!wired) { wire(); wired = true; }
      sendPreview();
      if (!db) {
        status("Uyarı: veritabanı bağlı değil, kaydetme çalışmaz. Vercel > Storage'dan Upstash Redis ekle.", "bad");
      } else {
        status("");
      }
    }).catch(function (err) {
      showLogin("Ayarlar yüklenemedi: " + err.message);
    });
  }

  window.addEventListener("beforeunload", function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ""; }
  });

  /* ---------- giriş ---------- */
  var dbFlag = false;
  $("#loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var b = $("#loginBtn"), err = $("#loginErr");
    b.disabled = true; err.textContent = "";
    api("/api/auth?action=login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: $("#pw").value }),
    }).then(function () {
      $("#pw").value = "";
      return api("/api/auth?action=status");
    }).then(function (st) {
      dbFlag = st.db;
      startEditor(st.db);
    }).catch(function (e2) {
      err.textContent = e2.message;
    }).then(function () { b.disabled = false; });
  });

  api("/api/auth?action=status").then(function (st) {
    dbFlag = st.db;
    if (!st.configured) {
      showLogin("Sunucuda ADMIN_PASSWORD ayarlı değil. Vercel > Settings > Environment Variables bölümünden ekleyip yeniden deploy et.");
      return;
    }
    if (st.authed) startEditor(st.db); else showLogin();
  }).catch(function () {
    showLogin("Sunucuya ulaşılamadı. Bu sayfa sadece Vercel'de (veya vercel dev ile) çalışır.");
  });
})();
