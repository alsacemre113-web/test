// Ortak yardımcılar: şifre/oturum, Redis (Upstash REST) ve ayar doğrulama.
// "_" ile başlayan dosyalar Vercel'de URL olarak yayınlanmaz.
const crypto = require('crypto');

const COOKIE = 'dat_admin';
const MAX_AGE = 60 * 60 * 8; // oturum süresi: 8 saat
const REDIS_KEY = 'dat:site-config';

// ---------- oturum ----------
function secret() {
  return process.env.SESSION_SECRET || process.env.ADMIN_PASSWORD || '';
}
function sign(data) {
  return crypto.createHmac('sha256', secret()).update(data).digest('base64url');
}
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}
function makeToken() {
  const body = Buffer.from(JSON.stringify({ exp: Date.now() + MAX_AGE * 1000 })).toString('base64url');
  return body + '.' + sign(body);
}
function readCookie(req, name) {
  const h = (req.headers && req.headers.cookie) || '';
  for (const part of h.split(';')) {
    const i = part.indexOf('=');
    if (i > -1 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return '';
}
function isAuthed(req) {
  if (!secret()) return false;
  const t = readCookie(req, COOKIE);
  const [body, sig] = t.split('.');
  if (!body || !sig) return false;
  if (!safeEqual(sig, sign(body))) return false;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return typeof p.exp === 'number' && p.exp > Date.now();
  } catch (e) {
    return false;
  }
}
function sessionCookie(token) {
  return `${COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${MAX_AGE}`;
}
function clearCookie() {
  return `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
}

// ---------- Redis (Upstash REST, ek paket gerekmez) ----------
function redisCfg() {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  return url && token ? { url, token } : null;
}
function hasDb() {
  return !!redisCfg();
}
async function redis(cmd) {
  const c = redisCfg();
  if (!c) throw new Error('NO_DB');
  const r = await fetch(c.url, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + c.token, 'Content-Type': 'application/json' },
    body: JSON.stringify(cmd),
  });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || 'DB ' + r.status);
  return j.result;
}

// ---------- ayar doğrulama ----------
const URL_RE = /^(https?:\/\/|mailto:|#|\/(?!\/))/i;
const IMG_RE = /^(https?:\/\/|\/(?!\/)|data:image\/(png|jpe?g|webp|gif);base64,)/i;
const COLOR_RE = /^#[0-9a-f]{6}$/i;

function str(v, max, name) {
  if (typeof v !== 'string') throw new Error(`${name} metin olmalı`);
  if (v.length > max) throw new Error(`${name} çok uzun (en fazla ${max} karakter)`);
  return v;
}
function arr(v, min, max, name) {
  if (!Array.isArray(v)) throw new Error(`${name} liste olmalı`);
  if (v.length < min || v.length > max) throw new Error(`${name} ${min}-${max} öğe içermeli`);
  return v;
}

function validateConfig(c) {
  try {
    if (!c || typeof c !== 'object' || Array.isArray(c)) throw new Error('Geçersiz veri');
    if (JSON.stringify(c).length > 600000) throw new Error('Veri çok büyük');
    if (typeof c.supply !== 'number' || !isFinite(c.supply) || c.supply <= 0) {
      throw new Error('Toplam arz pozitif bir sayı olmalı');
    }
    const out = {
      brand: str(c.brand, 100, 'Proje adı'),
      ticker: str(c.ticker, 30, 'Ticker'),
      chain: str(c.chain, 50, 'Ağ'),
      supply: c.supply,
      contract: str(c.contract, 200, 'Kontrat adresi'),
      tagline: str(c.tagline, 300, 'Slogan'),
      aboutTitle: str(c.aboutTitle, 200, 'Hakkında başlığı'),
      aboutText: str(c.aboutText, 2000, 'Hakkında metni'),
      roadSub: str(c.roadSub, 300, 'Roadmap alt başlığı'),
      disc1: str(c.disc1, 1000, 'Uyarı 1'),
      disc2: str(c.disc2, 1000, 'Uyarı 2'),
    };
    out.logo = str(c.logo, 500000, 'Logo');
    out.badge = str(c.badge, 500000, 'Rozet');
    if (!IMG_RE.test(out.logo)) throw new Error('Logo adresi / ile veya https:// ile başlamalı');
    if (!IMG_RE.test(out.badge)) throw new Error('Rozet adresi / ile veya https:// ile başlamalı');

    out.tokens = arr(c.tokens, 1, 20, 'Tokenomics').map((t, i) => {
      if (!t || typeof t.p !== 'number' || !isFinite(t.p) || t.p < 0 || t.p > 100) {
        throw new Error(`Tokenomics ${i + 1}. yüzde 0-100 arasında olmalı`);
      }
      if (!COLOR_RE.test(String(t.c))) throw new Error(`Tokenomics ${i + 1}. renk geçersiz`);
      return { n: str(t.n, 100, 'Dilim adı'), p: t.p, c: t.c, d: str(t.d, 200, 'Dilim açıklaması') };
    });
    const sum = out.tokens.reduce((s, t) => s + t.p, 0);
    if (Math.abs(sum - 100) > 0.001) throw new Error(`Tokenomics toplamı %100 olmalı (şu an %${+sum.toFixed(2)})`);

    out.phases = arr(c.phases, 1, 12, 'Roadmap').map((p) => ({
      title: str(p && p.title, 150, 'Faz başlığı'),
      tag: str(p && p.tag, 50, 'Faz etiketi'),
      items: arr(p && p.items, 0, 30, 'Faz maddeleri').map((x) => str(x, 200, 'Faz maddesi')),
    }));
    out.steps = arr(c.steps, 1, 12, 'Nasıl alınır').map((s) => ({
      title: str(s && s.title, 100, 'Adım başlığı'),
      text: str(s && s.text, 300, 'Adım metni'),
    }));
    out.links = arr(c.links, 0, 12, 'Linkler').map((l) => {
      const url = str(l && l.url, 500, 'Link adresi').trim();
      if (!URL_RE.test(url)) throw new Error(`"${url}" geçersiz link (https://, mailto: veya # ile başlamalı)`);
      return { name: str(l.name, 60, 'Link adı'), url };
    });
    return { ok: true, value: out };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

module.exports = {
  REDIS_KEY, secret, safeEqual, makeToken, isAuthed, sessionCookie, clearCookie,
  hasDb, redis, validateConfig,
};
