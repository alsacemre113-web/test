// GET  /api/auth?action=status  -> { authed, db, configured }
// POST /api/auth?action=login   -> { password }
// POST /api/auth?action=logout
const L = require('./_lib');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const action = (req.query && req.query.action) || 'status';

  if (req.method === 'GET' && action === 'status') {
    return res.status(200).json({
      configured: !!process.env.ADMIN_PASSWORD,
      authed: L.isAuthed(req),
      db: L.hasDb(),
    });
  }

  if (req.method === 'POST' && action === 'login') {
    if (!process.env.ADMIN_PASSWORD) {
      return res.status(503).json({ error: 'Sunucuda ADMIN_PASSWORD ayarlı değil.' });
    }
    const pw = req.body && req.body.password;
    if (typeof pw !== 'string' || !L.safeEqual(pw, process.env.ADMIN_PASSWORD)) {
      await sleep(800); // kaba kuvvet denemelerini yavaşlat
      return res.status(401).json({ error: 'Şifre yanlış.' });
    }
    res.setHeader('Set-Cookie', L.sessionCookie(L.makeToken()));
    return res.status(200).json({ ok: true });
  }

  if (req.method === 'POST' && action === 'logout') {
    res.setHeader('Set-Cookie', L.clearCookie());
    return res.status(200).json({ ok: true });
  }

  return res.status(405).json({ error: 'Desteklenmeyen istek.' });
};
