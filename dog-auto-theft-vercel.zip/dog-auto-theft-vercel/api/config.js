// GET    /api/config  -> herkese açık, güncel site ayarları
// PUT    /api/config  -> giriş gerekir, ayarları kaydeder
// DELETE /api/config  -> giriş gerekir, varsayılan ayarlara döner
const L = require('./_lib');
const DEFAULT = require('../config.default.json');

module.exports = async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');

  if (req.method === 'GET') {
    let cfg = null;
    try {
      const raw = await L.redis(['GET', L.REDIS_KEY]);
      if (raw) cfg = JSON.parse(raw);
    } catch (e) {
      // veritabanı yoksa veya hata varsa varsayılan ayarlarla devam et
    }
    const fresh = req.query && req.query.fresh;
    res.setHeader(
      'Cache-Control',
      fresh ? 'no-store' : 'public, max-age=0, s-maxage=15, stale-while-revalidate=60'
    );
    return res.status(200).json(cfg || DEFAULT);
  }

  if (req.method === 'PUT' || req.method === 'DELETE') {
    res.setHeader('Cache-Control', 'no-store');
    if (!L.isAuthed(req)) return res.status(401).json({ error: 'Giriş gerekli.' });
    if (!L.hasDb()) {
      return res.status(503).json({
        error: 'Veritabanı bağlı değil. Vercel > Storage bölümünden Upstash Redis ekleyip projeye bağla.',
      });
    }
    try {
      if (req.method === 'DELETE') {
        await L.redis(['DEL', L.REDIS_KEY]);
        return res.status(200).json({ ok: true });
      }
      const type = String((req.headers && req.headers['content-type']) || '');
      if (!type.includes('application/json')) return res.status(415).json({ error: 'JSON bekleniyor.' });
      const v = L.validateConfig(req.body);
      if (!v.ok) return res.status(400).json({ error: v.error });
      await L.redis(['SET', L.REDIS_KEY, JSON.stringify(v.value)]);
      return res.status(200).json({ ok: true });
    } catch (e) {
      return res.status(500).json({ error: 'Kaydedilemedi: ' + e.message });
    }
  }

  res.setHeader('Allow', 'GET, PUT, DELETE');
  return res.status(405).json({ error: 'Desteklenmeyen istek.' });
};
